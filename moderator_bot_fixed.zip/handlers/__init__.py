# handlers/__init__.py - auto-generated
