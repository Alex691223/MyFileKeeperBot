# utils/helpers.py - auto-generated
