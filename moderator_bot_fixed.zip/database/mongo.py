# database/mongo.py - auto-generated
